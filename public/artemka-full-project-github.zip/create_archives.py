import os
import zipfile

def create_docs_zip():
    docs_zip_path = 'public/artemka-docs.zip'
    with zipfile.ZipFile(docs_zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write('USER_MANUAL.md', arcname='USER_MANUAL.md')
        zf.write('README.md', arcname='README.md')
        zf.write('docs/GITHUB_INSTRUCTIONS.md', arcname='GITHUB_INSTRUCTIONS.md')
    print(f"Created {docs_zip_path}, size: {os.path.getsize(docs_zip_path)} bytes")

def create_full_repo_zip():
    repo_zip_path = 'public/artemka-full-project-github.zip'
    exclude_dirs = {
        'node_modules', '.git', 'dist', '.next', '.cache', '__pycache__', 'build'
    }
    exclude_exts = {
        '.pyc', '.zip'
    }

    with zipfile.ZipFile(repo_zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk('.'):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in exclude_exts:
                    continue
                if file.startswith('.') and file not in {'.gitignore', '.env.example'}:
                    continue
                
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, '.')
                # Do not include the zip file being written
                if 'public/artemka' in rel_path and rel_path.endswith('.zip'):
                    continue
                zf.write(full_path, arcname=rel_path)

    print(f"Created {repo_zip_path}, size: {os.path.getsize(repo_zip_path)} bytes")

if __name__ == '__main__':
    os.makedirs('public', exist_ok=True)
    create_docs_zip()
    create_full_repo_zip()
