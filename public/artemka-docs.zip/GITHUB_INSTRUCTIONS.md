# Пошаговая инструкция: Публикация проекта «Артёмка» на GitHub

Данная инструкция поможет вам опубликовать исходный код проекта в ваш личный репозиторий на GitHub и при желании развернуть его на GitHub Pages или Vercel/Netlify.

---

## Шаг 1. Создание нового репозитория на GitHub

1. Войдите в свой аккаунт на [GitHub](https://github.com).
2. В правом верхнем углу нажмите значок **`+`** и выберите **`New repository`**.
3. Заполните поля:
   - **Repository name**: например, `artemka-player` или `artemka-audio-therapy`
   - **Description**: `Терапевтический аудиоплеер со светофором, фабулами .flac, БРТ .mp3 и курсом 5/2`
   - **Visibility**: `Public` (открытый) или `Private` (приватный) по вашему желанию.
   - **Initialize this repository with**: **НЕ ставьте галочки** напротив README, .gitignore или license (так как все эти файлы уже созданы в нашем проекте).
4. Нажмите зелёную кнопку **`Create repository`**.
5. Скопируйте URL созданного репозитория (например, `https://github.com/ВАШ_ЛОГИН/artemka-player.git`).

---

## Шаг 2. Инициализация Git и отправка кода (Push)

Откройте терминал в папке с распакованным проектом и выполните команды:

```bash
# 1. Инициализируем локальный Git-репозиторий
git init

# 2. Переименовываем основную ветку в main
git branch -M main

# 3. Добавляем все файлы проекта (node_modules и временные файлы автоматически игнорируются)
git add .

# 4. Создаем первый коммит
git commit -m "Initial commit: Artemka audio therapy player v1.0"

# 5. Привязываем ваш удаленный репозиторий GitHub (замените URL на свой!)
git remote add origin https://github.com/ВАШ_ЛОГИН/artemka-player.git

# 6. Отправляем код на GitHub
git push -u origin main
```

---

## Шаг 3. Быстрое бесплатное развёртывание в интернете (Vercel / Netlify / GitHub Pages)

### Вариант А: Деплой через Vercel (рекомендуется, 1 минута)
1. Перейдите на [vercel.com](https://vercel.com) и авторизуйтесь через GitHub.
2. Нажмите **Add New... $\rightarrow$ Project**.
3. Выберите ваш репозиторий `artemka-player`.
4. Vercel автоматически определит **Vite** и настройки сборки (`npm run build`, output directory: `dist`).
5. Нажмите **Deploy**. Через 30 секунд ваше приложение получит бесплатный публичный HTTPS-домен.

### Вариант Б: Деплой через GitHub Pages
1. В `package.json` можно добавить `"homepage": "https://ВАШ_ЛОГИН.github.io/artemka-player"`.
2. В `vite.config.ts` установить `base: './'`.
3. Запустить `npm run build` и настроить раздачу из ветки `gh-pages` или папки `dist`.

---

## Шаг 4. Сборка мобильного приложения Android (APK)

В репозитории уже настроена папка `android/` с конфигурацией Capacitor.
Для генерации APK:
```bash
npm install
npm run build
npx cap sync android
npx cap open android
```
В Android Studio нажмите **Build $\rightarrow$ Build APK(s)** и готовый установочный файл `.apk` будет собран для вашего смартфона или планшета!
